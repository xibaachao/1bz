<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>标题</title>
	<meta name="keywords" content=""/>
	<meta name="description" content=''/>
	<link rel="stylesheet" type="text/css" href="../Public/css/style.css">
	<link rel="stylesheet" type="text/css" href="../Public/css/animate.min.css">
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
	<style type="text/css">
	#a5{
		-webkit-animation-duration: 2s;
		-webkit-animation-delay: 4s;
		-webkit-animation-iteration-count: 1;
	}
	</style>
</head>
<body>
	<div class="index_bg">
		<div >
			<img src="../Public/images/1_logo_01.png" width="40%" class="animated fadeInLeft">
		</div>
		<div style="width:70%;margin:0 auto;position:absolute; left:-1000px; top:25%;" id="a1">
			<img src="../Public/images/eleme-0_04.png" width="100%">
		</div>
		<div id="a2" style="width:70%;margin:0 auto;margin:0 auto;position:absolute; left:-1000px; top:40%;" >
			<img src="../Public/images/eleme-0_07.png" width="100%">
		</div>
		<div id="a3" style="width:70%;margin:0 auto;margin-top:20px;margin:0 auto;position:absolute; left:-1000px; top:48%;" >
			<img src="../Public/images/eleme-0_09.png" width="100%">
		</div>
		<div style="width:80%;margin:0 auto;position:absolute; top:65%;left:15%" class="animated swing" id="a5">
			<a href="__URL__/ff"><img src="../Public/images/eleme-0_12.png" width="100%"></a>
		</div>
	</div>
		<div style="display:none">
		<script src="http://s95.cnzz.com/z_stat.php?id=1257184940&web_id=1257184940" language="JavaScript"></script>
	</div>
</body>
<script type="text/javascript" src="http://apps.bdimg.com/libs/jquery/1.8.0/jquery.min.js"></script>
<script type="text/javascript">
	$(function(){
		$("#a1").animate({
			left:"15%",
		},2000);
		$("#a2").animate({
			left:"15%",
		},3000);
		$("#a3").animate({
			left:"15%",
		},4000);
	})

</script>
</html>