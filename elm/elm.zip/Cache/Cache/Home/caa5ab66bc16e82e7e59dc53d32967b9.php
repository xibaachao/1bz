<?php if (!defined('THINK_PATH')) exit();?><audio src="../Public/1.mp3" loop="loop" autoplay="autoplay">
</audio>