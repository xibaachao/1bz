<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>标题</title>
	<meta name="keywords" content=""/>
	<meta name="description" content=''/>
	<link rel="stylesheet" type="text/css" href="../Public/css/style.css">
	<link rel="stylesheet" type="text/css" href="../Public/css/animate.min.css">
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
	<style type="text/css">
		#t{
			-webkit-animation-duration: 6s;
			-webkit-animation-delay: 1s;
			-webkit-animation-iteration-count: infinite;
		}
		#t1{
			-webkit-animation-duration: 2s;
			-webkit-animation-delay: 1s;
			-webkit-animation-iteration-count: 1;
		}
		#t2{
			-webkit-animation-duration: 2s;
			-webkit-animation-delay: 1s;
			-webkit-animation-iteration-count: 1;
		}
	</style>
</head>
<body>
	<div class="f8">
		<div style="width:100%;text-align:center">
			<img src="../Public/images/dx-1_02.png" width="40%">
		</div>
		<div style="position: absolute;top:18%;width:100%">
			<img src="../Public/images/dx-2_03.png"  width="100%" class="animated fadeInUp" id="t1">
		</div>
		<div style="position: absolute;top:65%;width:100%;text-align:center">
			<a href="https://h.ele.me/baida?group_sn=8613f8ff0f20c46a771eb44f97c94b8d&from=groupmessage&isappinstalled=0"><img src="../Public/images/dx-1_06.png"  width="80%" class="animated rotateIn" id="t1"></a>
		</div>
		<div style="position: absolute;top:73%;width:100%;text-align:center">
			<img src="../Public/images/dx-1_08.png"  width="100%" class="animated fadeInUp" id="t2">
		</div>
		
			<img src="../Public/images/dx-2_05.png" width="100%" style="position:fixed;bottom:0px">			
		
	</div>
		<div style="display:none">
		<script src="http://s95.cnzz.com/z_stat.php?id=1257184940&web_id=1257184940" language="JavaScript"></script>
	</div>
</body>
</html>