<?php
class VoteAction extends ManageAction{
	
}