<?php

return array(
    'DB_DSN' => 'mysql://root:root@localhost/ct',
    'DB_PREFIX' => 'ct_',
    'APP_GROUP_LIST' => 'Admin,Home,WeiXin',
    'APP_GROUP_MODE' => 1,
    'APP_GROUP_PATH' => 'Njs',
    'DEFAULT_GROUP' => 'Home',
    'TOKEN_ON' => false,
    'SHOW_PAGE_TRACE' => false,
);
 